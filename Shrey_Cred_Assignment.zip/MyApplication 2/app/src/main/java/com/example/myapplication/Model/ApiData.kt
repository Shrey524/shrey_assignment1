package com.example.myapplication.Model

import androidx.core.app.NotificationCompat.Action.SemanticAction
import com.google.gson.annotations.SerializedName

data class ApiData(
    val success: Boolean?
)
